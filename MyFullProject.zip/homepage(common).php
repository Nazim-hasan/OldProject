<?php include_once "header(user).php";?>
<!-- homepage(common) starts -->
<div class="main-content">
    <h2>Main Content</h2>
</div>
<!-- homepage(common) ends -->
<?php include_once "footer.php";?>