        <!-- Footer starts -->
        <footer class="footer" align="center">
            <ul class="plain-bullet">
                <li><a href="#">About Us</a></li>
                <li><a href="#">Terms & Conditions</a></li>
                <li><a href="contactUs.php">Contact Us</a></li>
                <li><a href="#">Online Support Service</a></li>                
            </ul>
        </footer>
    </body>
</html>
<!-- Footer ends -->