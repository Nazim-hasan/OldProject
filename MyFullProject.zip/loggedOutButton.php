<head>
<link rel="stylesheet" href="styles/basicLayout.css">
</head>
<li><a href="registration.php" class="right">Registration</a></li>
<li><a href="login.php" class="right">Login</a></li>