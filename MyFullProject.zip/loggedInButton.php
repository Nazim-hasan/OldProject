<head>
<link rel="stylesheet" href="styles/basicLayout.css">
</head>
<li><a href="myAccount.php" class="right">My Account</a></li>
<li><a href="logout.php" class="right">Logout</a></li>