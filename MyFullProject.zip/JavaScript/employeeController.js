function get(id)
{
    return document.getElementById(id);
}
function validate()
{
    refresh();
    var hasError=false;
    var name = get('name');
    var email = get('email')
    var phone = get('phone');

    //Name Validation
    if(name.value=="")
    {
        get('err_name').innerHTML="*Enter Name *";
        hasError = true;
    }
    //Phone Number Validation
    if(phone.value =="")
    {
        get('err_phonenum').innerHTML="*Enter Phone Number *";

        hasError = true;
    }
    else if(isNaN(phone.value))
    {
        get('err_phonenum').innerHTML="*Enter only Numeric Values*";

        hasError = true;
    }

    //Email Validation
    if(email.value == '')
    {
        get('err_email').innerHTML="*Enter Email *";
        hasError = true;
    }
    else if(!email.value.includes("@"))
    {
        get('err_email').innerHTML="*@ sign required*";
        hasError = true;
    }
    else if(email.value.includes(" "))
    {
        get('err_email').innerHTML="*Username can't contain whitespaces*";
        hasError = true;
    }
    else if(!email.value.includes(".",email.value.indexOf("@")))
    {
        get('err_email').innerHTML="*dot(.) required after @*";
        hasError = true;
    }



    return !hasError;

}

function refresh()
{
get('err_name').innerHTML="";
get('err_username').innerHTML="";
get('err_password').innerHTML="";
get('err_conpassword').innerHTML="";
get('err_email').innerHTML="";
get('err_phonenum').innerHTML="";

}
