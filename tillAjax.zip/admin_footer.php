
		<!--addproduct ends -->
		<!--footer-->
		<footer class="footer">
			<h4>admin footer</h4>
		</footer>
		
	</body>
</html>