<?php include 'admin_header.php';
require_once "CONTROLLER/add_employee_controller.php";?>
<!--addproduct starts -->
<head>
		<link rel="stylesheet" href="styles/basicLayout.css">
<script src="JavaScript/emoloyeeController.js"></script>

</head>
<div class="center">
<form action="" onsubmit="return validate()" method="POST">
		<div class="form-group">
			<h4 class="text">Emloyee's Name:</h4>
			<input type="text" name="ename" id="name" class="form-control">
			<br><span class="err-msg" id="err_name"><?php echo $err_ename;?>
		</div>


    <div class="form-group">
			<h4 class="text">Employee's PhoneNumber:</h4>
			<input type="text" name="phone" id="phone" maxlength="50" class="form-control">
			<br><span class="err-msg" id="err_phonenum"><?php echo $err_number;?>
		</div>


    <div class="form-group">
      <h4 class="text">Employee's Email:</h4>
      <input type="text" name="email" maxlength="50" class="form-control">
      <?php echo $err_email;?>
    </div>


    <div class="form-group">
      <h4 class="text">Employee's Address:</h4>
      <input type="text" name="eaddress" maxlength="50" class="form-control">
      <?php echo $err_eaddress;?>
    </div>


    <div class="form-group">
			<h4 class="text">Job Position:</h4>
			<select name="jpos" class="form-control">
				<option selected disabled>Choose</option>
				<option>Cashier</option>
				<option>Customer Service Assistant</option>
				<option>Order Picker</option>
				<option>Stock Clerk</option>
			</select>
			<?php echo $err_jpos;?>
		</div>




		<div class="form-group">
			<h4 class="text">Employee's Salary:</h4>
			<input type="text" name="esalary" maxlength="50" class="form-control">
			<?php echo $err_esalary;?>
		</div>



		<div class="form-group text-center">

			<input type="submit" name="add_employee" class="btn btn-success" value="Add Employee" class="form-control">
		</div>
	</form>
</div>
<?php include 'admin_footer.php';?>
