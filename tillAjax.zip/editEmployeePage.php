<?php include 'C:\xampp\htdocs\WebTech\Project V2\admin_header.php';?>





<div class="center">
	<h3 class="text">Modify Employees</h3>
	<table class="table table-striped">
		<thead>
			<th>Sl#</th>
			<th>Name</th>
			<th>Position</th>
			<th>Department</th>
			<th>Salary</th>

			<th>Edit</th>
		</thead>
		<tbody>
			<td>1</td>
			<td>Rafiq</td>
			<td>Cashier</td>
			<td>IT</td>
			<td>10000</td>
      <td><a href="editEmployee.php" class="btn btn-success">Edit</a></td>
		</tbody>
    <tbody>
			<td>2</td>
			<td>Ibrahim</td>
			<td>Slaes</td>
			<td>IT</td>
			<td>20000</td>
      <td><a href="editEmployee.php" class="btn btn-success">Edit</a></td>
		</tbody>
    <tbody>
			<td>3</td>
			<td>Shaikat</td>
			<td>Cashier</td>
			<td>IT</td>
			<td>30000</td>
      <td><a href="editEmployee.php" class="btn btn-success">Edit</a></td>
		</tbody>
	</table>
</div>
<!--dashboard ends -->
<?php include 'admin_footer.php';?>
